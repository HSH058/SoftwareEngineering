package AnimalFram;

import java.util.ArrayList;

public class AnimalFram {
	// 동물 객체를 저장할 ArrayList 생성
	ArrayList<Animal> animals = new ArrayList<>();
	
	// 새로운 동물을 동물농장에 추가하는 메서드
    public void addAnimal(Animal animal) {
        animals.add(animal);
    }
    
	public AnimalFram() {
		Dog dog = new Dog("멍멍이", "10", "갈색");
	    Cat cat = new Cat("야옹이", "5", "흰색");
	    Chicken chicken = new Chicken("닭닭이", "2", "황색");
		
	    animals.add(dog);
	    animals.add(cat);
	    animals.add(chicken);
		
		dog.MyAttributePrint();
		cat.MyAttributePrint();	
		chicken.MyAttributePrint();
	}
	
	// 농장 안에 있는 모든 동물에게 소리를 내도록 하는 메서드
    public void makeAllAnimalsSpeak() {
        for (Animal animal : animals) {
            animal.Speak();
        }
    }
	//농장 안에 있는 모든 동물의 이름/무게/색깔 표로 출력하라고 시키기
	public void Animalprint() {
		 // 표 형식으로 출력
	    System.out.println("+------------+------------+------------+");
	    System.out.printf("| %-10s | %-10s | %-10s |%n", "Name", "Weight", "Color");
	    System.out.println("+------------+------------+------------+");

	    for (Animal animal : animals) {
	        System.out.printf("| %-10s | %-10.2s | %-10s |%n", animal.getName(), animal.getWeight(), animal.getColor());
	        System.out.println("+------------+------------+------------+");
	    }
	}
	
	// 이름으로 동물 찾기
	public void Animalsearch(String searchName){
	    Animal foundAnimal = findAnimalByName(animals, searchName);
	    if (foundAnimal != null) {
	        System.out.println("찾은 동물: " + foundAnimal.getName());
	    } 
	    else {
	        System.out.println("동물을 찾을 수 없습니다.");
	    }
	}
	public static Animal findAnimalByName(ArrayList<Animal> animals, String name) {
        for (Animal animal : animals) {
            if (animal.getName().equalsIgnoreCase(name)) {
                return animal;
            }
        }
        return null; // 해당 이름을 가진 동물이 없을 경우 null 반환
    }
}

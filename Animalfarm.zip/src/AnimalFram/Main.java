package AnimalFram;

public class Main {

	public static void main(String[] args) {
		AnimalFram aa = new AnimalFram();
		Dog dog1 = new Dog("멍뭉이", "12", "파랑");
		//객체 추가하기
		aa.addAnimal(dog1);
		//동물 객체 찾기 및 속성 출력하기
		aa.Animalsearch("야옹이");
		//속성값 표로 출력하기
		aa.Animalprint();
		//소리내기
		aa.makeAllAnimalsSpeak();
	}

}

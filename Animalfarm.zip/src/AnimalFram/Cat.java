package AnimalFram;

public class Cat extends Animal{
	public Cat(String name, String weight, String color) {
        super(name, weight, color);
    }
	public void Speak(){
		System.out.println("야용~");
	}
	public void MyAttributePrint() {
		System.out.println("이름 : " + name + ", 무게 : " + weight + "kg" + ", 색깔 : " + color + "\n");
	}
}

package AnimalFram;

public class Animal {
	public String name;
	public String weight;
	public String color;

	public Animal(String name, String weight, String color) {
		this.name = name;
		this.weight = weight;
		this.color = color;
	}
	
	public void Speak() {
		System.out.println("동물 소리");
	}
	
	public void MyAttributePrint() {
		System.out.println("속성 출력");
	}
	
	public String getName() {
        return name;
    }

    public String getWeight() {
        return weight;
    }

    public String getColor() {
        return color;
    }
}

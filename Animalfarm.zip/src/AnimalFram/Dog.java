package AnimalFram;

public class Dog extends Animal{
	public Dog(String name, String weight, String color) {
        super(name, weight, color);
    }
	public void Speak(){
		System.out.println("멍멍!");
	}
	public void MyAttributePrint() {
		System.out.println("이름 : " + name + ", 무게 : " + weight + "kg" + ", 색깔 : " + color + "\n");
	}
}
